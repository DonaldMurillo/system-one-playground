module github.com/DonaldMurillo/system-one-playground

go 1.25.0

require github.com/pelletier/go-toml/v2 v2.2.4
